function a = Prod(A,B)
a = sum(A.*B,'all');