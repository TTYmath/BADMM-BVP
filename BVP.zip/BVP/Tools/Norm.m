function t = Norm(A)
t = sqrt(sum(A.*A,'all'));